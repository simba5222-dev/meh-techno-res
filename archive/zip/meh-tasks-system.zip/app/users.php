<?php
require __DIR__ . '/includes/bootstrap.php';
$user = require_admin();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create') {
    csrf_verify();

    $fullName = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = (string) ($_POST['password'] ?? '');
    $role = $_POST['role'] ?? 'mechanic';
    $phone = trim($_POST['phone'] ?? '');

    if ($fullName === '') $errors[] = 'Укажите ФИО.';
    if ($username === '') $errors[] = 'Укажите логин.';
    if (!preg_match('/^[A-Za-z0-9_.\-]{3,100}$/', $username)) $errors[] = 'Логин: латиница, цифры, точка, дефис, подчёркивание, от 3 символов.';
    if (strlen($password) < 6) $errors[] = 'Пароль должен быть не короче 6 символов.';
    if (!in_array($role, ['admin', 'mechanic'], true)) $errors[] = 'Некорректная роль.';

    if (!$errors) {
        try {
            $stmt = db()->prepare('INSERT INTO users (full_name, username, password_hash, role, phone) VALUES (?,?,?,?,?)');
            $stmt->execute([$fullName, $username, password_hash($password, PASSWORD_DEFAULT), $role, $phone ?: null]);
            flash('success', 'Пользователь создан.');
            redirect('users.php');
        } catch (PDOException $ex) {
            $errors[] = $ex->getCode() === '23000' ? 'Такой логин уже занят.' : ('Ошибка: ' . $ex->getMessage());
        }
    }
}

// Быстрые действия: деактивировать/активировать
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'toggle_active') {
    csrf_verify();
    $targetId = (int) ($_POST['user_id'] ?? 0);
    if ($targetId && $targetId !== (int) $user['id']) {
        $stmt = db()->prepare('UPDATE users SET is_active = NOT is_active WHERE id = ?');
        $stmt->execute([$targetId]);
        flash('success', 'Статус учётной записи обновлён.');
    } else {
        flash('error', 'Нельзя отключить собственную учётную запись.');
    }
    redirect('users.php');
}

$users = db()->query('SELECT * FROM users ORDER BY role DESC, full_name ASC')->fetchAll();

require __DIR__ . '/includes/header.php';
?>
<div class="page-head">
    <h1>Пользователи</h1>
</div>

<?php foreach ($errors as $err): ?>
    <div class="flash flash-error"><?= e($err) ?></div>
<?php endforeach; ?>

<div class="table-wrap">
<table class="data-table">
    <thead>
        <tr><th>ФИО</th><th>Логин</th><th>Роль</th><th>Телефон</th><th>Статус</th><th></th></tr>
    </thead>
    <tbody>
    <?php foreach ($users as $u): ?>
        <tr>
            <td><?= e($u['full_name']) ?></td>
            <td><?= e($u['username']) ?></td>
            <td><?= $u['role'] === 'admin' ? 'Главный механик' : 'Линейный механик' ?></td>
            <td><?= e($u['phone'] ?? '—') ?></td>
            <td><span class="badge <?= $u['is_active'] ? 'badge-verified' : 'badge-rejected' ?>"><?= $u['is_active'] ? 'Активен' : 'Отключён' ?></span></td>
            <td class="actions-cell">
                <a href="user_edit.php?id=<?= (int) $u['id'] ?>">Изменить</a>
                <?php if ((int) $u['id'] !== (int) $user['id']): ?>
                    · <form method="post" class="inline-form" onsubmit="return confirm('Изменить статус учётной записи?');">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="toggle_active">
                        <input type="hidden" name="user_id" value="<?= (int) $u['id'] ?>">
                        <button type="submit" class="btn-link"><?= $u['is_active'] ? 'Отключить' : 'Включить' ?></button>
                    </form>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</div>

<h2>Добавить пользователя</h2>
<form method="post" class="form-card">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="create">
    <div class="form-row">
        <label>ФИО *
            <input type="text" name="full_name" required value="<?= e($_POST['full_name'] ?? '') ?>">
        </label>
        <label>Логин *
            <input type="text" name="username" required value="<?= e($_POST['username'] ?? '') ?>">
        </label>
    </div>
    <div class="form-row">
        <label>Пароль *
            <input type="text" name="password" required minlength="6" placeholder="не короче 6 символов">
        </label>
        <label>Телефон
            <input type="text" name="phone" value="<?= e($_POST['phone'] ?? '') ?>">
        </label>
    </div>
    <label>Роль
        <select name="role">
            <option value="mechanic">Линейный механик</option>
            <option value="admin">Главный механик</option>
        </select>
    </label>
    <button type="submit" class="btn btn-primary">Создать пользователя</button>
</form>

<?php require __DIR__ . '/includes/footer.php'; ?>
