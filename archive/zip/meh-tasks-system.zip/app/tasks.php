<?php
require __DIR__ . '/includes/bootstrap.php';
$user = require_login();

$isAdmin = $user['role'] === 'admin';

$assigneeFilter = $isAdmin ? ($_GET['assignee_id'] ?? '') : (string) $user['id'];
$equipmentFilter = trim($_GET['equipment'] ?? '');
$showClosed = isset($_GET['show_closed']);

$sql = "SELECT t.*, e.inventory_number, e.name AS equipment_name, u1.full_name AS assignee_name, u2.full_name AS creator_name,
        (SELECT COUNT(*) FROM task_photos p WHERE p.task_id = t.id) AS photo_count
        FROM tasks t
        JOIN equipment e ON e.id = t.equipment_id
        LEFT JOIN users u1 ON u1.id = t.assignee_id
        LEFT JOIN users u2 ON u2.id = t.created_by
        WHERE 1=1";
$params = [];

if ($assigneeFilter !== '') {
    $sql .= ' AND t.assignee_id = ?';
    $params[] = (int) $assigneeFilter;
}

if ($equipmentFilter !== '') {
    $sql .= ' AND (e.name LIKE ? OR e.inventory_number LIKE ?)';
    $like = '%' . $equipmentFilter . '%';
    $params[] = $like;
    $params[] = $like;
}

if (!$showClosed) {
    $sql .= " AND t.status != 'verified'";
}

$sql .= ' ORDER BY FIELD(t.priority,\'urgent\',\'high\',\'normal\',\'low\'), t.due_date IS NULL, t.due_date ASC, t.created_at DESC';

$stmt = db()->prepare($sql);
$stmt->execute($params);
$allTasks = $stmt->fetchAll();

$columns = [
    'new' => [],
    'accepted' => [],
    'in_progress' => [],
    'done' => [],
    'rejected' => [],
];
if ($showClosed) {
    $columns['verified'] = [];
}

foreach ($allTasks as $t) {
    if (isset($columns[$t['status']])) {
        $columns[$t['status']][] = $t;
    }
}

$mechanicsForFilter = $isAdmin ? db()->query("SELECT id, full_name FROM users WHERE role='mechanic' AND is_active=1 ORDER BY full_name")->fetchAll() : [];

require __DIR__ . '/includes/header.php';
?>
<div class="page-head">
    <h1><?= $isAdmin ? 'Задачи' : 'Мои задачи' ?></h1>
    <?php if ($isAdmin): ?>
        <a href="task_create.php" class="btn btn-primary">+ Новая задача</a>
    <?php endif; ?>
</div>

<form method="get" class="filter-bar">
    <?php if ($isAdmin): ?>
        <select name="assignee_id">
            <option value="">Все механики</option>
            <?php foreach ($mechanicsForFilter as $m): ?>
                <option value="<?= (int) $m['id'] ?>" <?= (string) $assigneeFilter === (string) $m['id'] ? 'selected' : '' ?>><?= e($m['full_name']) ?></option>
            <?php endforeach; ?>
        </select>
    <?php endif; ?>
    <input type="text" name="equipment" placeholder="Поиск по технике" value="<?= e($equipmentFilter) ?>">
    <label class="checkbox-label"><input type="checkbox" name="show_closed" value="1" <?= $showClosed ? 'checked' : '' ?> onchange="this.form.submit()"> показать проверенные</label>
    <button type="submit" class="btn">Применить</button>
</form>

<div class="kanban">
    <?php
    $columnTitles = [
        'new' => 'Новые',
        'accepted' => 'Приняты',
        'in_progress' => 'В работе',
        'done' => 'Выполнены',
        'rejected' => 'На доработке',
        'verified' => 'Проверены',
    ];
    foreach ($columns as $statusKey => $tasksInCol):
    ?>
    <div class="kanban-col">
        <div class="kanban-col-head">
            <span><?= $columnTitles[$statusKey] ?></span>
            <span class="count"><?= count($tasksInCol) ?></span>
        </div>
        <div class="kanban-col-body">
            <?php if (!$tasksInCol): ?>
                <div class="kanban-empty">пусто</div>
            <?php endif; ?>
            <?php foreach ($tasksInCol as $t): ?>
                <a class="task-card <?= task_is_overdue($t) ? 'task-card-overdue' : '' ?>" href="task_view.php?id=<?= (int) $t['id'] ?>">
                    <div class="task-card-title">#<?= (int) $t['id'] ?> <?= e($t['title']) ?></div>
                    <div class="task-card-eq"><?= e($t['inventory_number'] . ' · ' . $t['equipment_name']) ?></div>
                    <div class="task-card-meta">
                        <span class="badge <?= priority_class($t['priority']) ?>"><?= priority_label($t['priority']) ?></span>
                        <?php if ($isAdmin): ?><span class="assignee"><?= e($t['assignee_name'] ?? 'не назначен') ?></span><?php endif; ?>
                    </div>
                    <?php if ($t['due_date']): ?>
                        <div class="task-card-due <?= task_is_overdue($t) ? 'overdue-text' : '' ?>">
                            срок: <?= fmt_date($t['due_date']) ?><?= task_is_overdue($t) ? ' ⚠ просрочено' : '' ?>
                        </div>
                    <?php endif; ?>
                    <?php if ($t['photo_count'] > 0): ?><div class="task-card-photos">📷 <?= (int) $t['photo_count'] ?></div><?php endif; ?>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
