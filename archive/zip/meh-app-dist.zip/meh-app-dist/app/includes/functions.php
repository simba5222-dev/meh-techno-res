<?php
/**
 * Общие вспомогательные функции.
 */

/** Безопасный вывод строки в HTML */
function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/** CSRF-токен: получить (создать при необходимости) */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** CSRF-токен: скрытое поле для формы */
function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

/** CSRF-токен: проверка при обработке POST-запроса */
function csrf_verify(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!$token || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(400);
        die('Ошибка проверки формы (CSRF). Обновите страницу и попробуйте снова.');
    }
}

/** Редирект с последующим завершением скрипта */
function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

/** Положить flash-сообщение в сессию */
function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

/** Забрать и очистить flash-сообщения */
function get_flashes(): array
{
    $flashes = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $flashes;
}

/** Человекочитаемые статусы задач */
function task_status_label(string $status): string
{
    return match ($status) {
        'new' => 'Новая',
        'accepted' => 'Принята',
        'in_progress' => 'В работе',
        'done' => 'Выполнена',
        'verified' => 'Проверена',
        'rejected' => 'Возвращена на доработку',
        default => $status,
    };
}

/** CSS-класс бейджа под статус задачи */
function task_status_class(string $status): string
{
    return match ($status) {
        'new' => 'badge-new',
        'accepted' => 'badge-accepted',
        'in_progress' => 'badge-progress',
        'done' => 'badge-done',
        'verified' => 'badge-verified',
        'rejected' => 'badge-rejected',
        default => '',
    };
}

/** Человекочитаемые приоритеты */
function priority_label(string $priority): string
{
    return match ($priority) {
        'low' => 'Низкий',
        'normal' => 'Обычный',
        'high' => 'Высокий',
        'urgent' => 'Срочно',
        default => $priority,
    };
}

function priority_class(string $priority): string
{
    return match ($priority) {
        'low' => 'prio-low',
        'normal' => 'prio-normal',
        'high' => 'prio-high',
        'urgent' => 'prio-urgent',
        default => '',
    };
}

/** Человекочитаемый статус техники */
function equipment_status_label(string $status): string
{
    return match ($status) {
        'working' => 'В работе',
        'repair' => 'На ремонте',
        'idle' => 'Простой',
        default => $status,
    };
}

function equipment_status_class(string $status): string
{
    return match ($status) {
        'working' => 'badge-verified',
        'repair' => 'badge-rejected',
        'idle' => 'badge-new',
        default => '',
    };
}

/** Формат даты для отображения */
function fmt_date(?string $datetime): string
{
    if (!$datetime) {
        return '—';
    }
    $ts = strtotime($datetime);
    return $ts ? date('d.m.Y', $ts) : '—';
}

/** Формат даты и времени для отображения */
function fmt_datetime(?string $datetime): string
{
    if (!$datetime) {
        return '—';
    }
    $ts = strtotime($datetime);
    return $ts ? date('d.m.Y H:i', $ts) : '—';
}

/** Просрочена ли задача (есть срок, он прошёл, задача не закрыта) */
function task_is_overdue(array $task): bool
{
    if (empty($task['due_date'])) {
        return false;
    }
    if (in_array($task['status'], ['verified', 'rejected'], true)) {
        return false;
    }
    return strtotime($task['due_date']) < strtotime(date('Y-m-d'));
}

/**
 * Сохранить загруженные фотографии к задаче.
 * Возвращает массив: ['saved' => int, 'errors' => string[]]
 */
function save_task_photos(int $taskId, int $userId, array $filesInput): array
{
    $saved = 0;
    $errors = [];

    if (empty($filesInput['name'][0])) {
        return ['saved' => 0, 'errors' => []];
    }

    $allowedExt = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
    $targetDir = rtrim(UPLOAD_DIR, '/') . '/' . $taskId;

    if (!is_dir($targetDir)) {
        if (!mkdir($targetDir, 0755, true) && !is_dir($targetDir)) {
            return ['saved' => 0, 'errors' => ['Не удалось создать папку для загрузки файлов.']];
        }
    }

    $count = count($filesInput['name']);
    for ($i = 0; $i < $count; $i++) {
        if ($filesInput['error'][$i] === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        if ($filesInput['error'][$i] !== UPLOAD_ERR_OK) {
            $errors[] = 'Ошибка загрузки файла «' . $filesInput['name'][$i] . '».';
            continue;
        }
        if ($filesInput['size'][$i] > MAX_UPLOAD_SIZE) {
            $errors[] = 'Файл «' . $filesInput['name'][$i] . '» превышает допустимый размер (10 МБ).';
            continue;
        }

        $ext = strtolower(pathinfo($filesInput['name'][$i], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowedExt, true)) {
            $errors[] = 'Файл «' . $filesInput['name'][$i] . '»: недопустимый формат (разрешены JPG, PNG, WEBP, GIF).';
            continue;
        }

        $newName = bin2hex(random_bytes(8)) . '.' . $ext;
        $destPath = $targetDir . '/' . $newName;

        if (move_uploaded_file($filesInput['tmp_name'][$i], $destPath)) {
            $relativePath = UPLOAD_URL . '/' . $taskId . '/' . $newName;
            $stmt = db()->prepare('INSERT INTO task_photos (task_id, file_path, uploaded_by) VALUES (?,?,?)');
            $stmt->execute([$taskId, $relativePath, $userId]);
            $saved++;
        } else {
            $errors[] = 'Не удалось сохранить файл «' . $filesInput['name'][$i] . '».';
        }
    }

    return ['saved' => $saved, 'errors' => $errors];
}

/** Допустимые переходы статусов задачи в зависимости от роли */
function allowed_transitions(string $currentStatus, string $role): array
{
    if ($role === 'admin') {
        return match ($currentStatus) {
            'new' => ['in_progress', 'rejected'],
            'accepted' => ['in_progress', 'rejected'],
            'in_progress' => ['rejected'],
            'done' => ['verified', 'rejected'],
            'rejected' => ['in_progress'],
            'verified' => [],
            default => [],
        };
    }

    // Линейный механик
    return match ($currentStatus) {
        'new' => ['accepted'],
        'accepted' => ['in_progress'],
        'in_progress' => ['done'],
        'rejected' => ['in_progress'],
        default => [],
    };
}
