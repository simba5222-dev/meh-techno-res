</div>
<?php if (!empty($user)): ?>
  </main>
</div>
<?php endif; ?>
<script src="assets/app.js"></script>
</body>
</html>
