<?php
require __DIR__ . '/includes/bootstrap.php';
$admin = require_admin();

$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
$stmt->execute([$id]);
$target = $stmt->fetch();

if (!$target) {
    flash('error', 'Пользователь не найден.');
    redirect('users.php');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $fullName = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $role = $_POST['role'] ?? $target['role'];
    $newPassword = (string) ($_POST['new_password'] ?? '');

    if ($fullName === '') $errors[] = 'Укажите ФИО.';
    if (!in_array($role, ['admin', 'mechanic', 'manager'], true)) $errors[] = 'Некорректная роль.';
    if ($newPassword !== '' && strlen($newPassword) < 6) $errors[] = 'Новый пароль должен быть не короче 6 символов.';

    if ((int) $target['id'] === (int) $admin['id'] && $role !== 'admin') {
        $errors[] = 'Нельзя понизить роль собственной учётной записи.';
    }

    if (!$errors) {
        if ($newPassword !== '') {
            $stmt = db()->prepare('UPDATE users SET full_name=?, phone=?, role=?, password_hash=? WHERE id=?');
            $stmt->execute([$fullName, $phone ?: null, $role, password_hash($newPassword, PASSWORD_DEFAULT), $id]);
        } else {
            $stmt = db()->prepare('UPDATE users SET full_name=?, phone=?, role=? WHERE id=?');
            $stmt->execute([$fullName, $phone ?: null, $role, $id]);
        }
        flash('success', 'Данные пользователя обновлены.');
        redirect('users.php');
    }

    $target['full_name'] = $fullName;
    $target['phone'] = $phone;
    $target['role'] = $role;
}

require __DIR__ . '/includes/header.php';
?>
<div class="page-head">
    <h1>Редактирование пользователя</h1>
    <a href="users.php" class="btn-link">← К списку</a>
</div>

<?php foreach ($errors as $err): ?>
    <div class="flash flash-error"><?= e($err) ?></div>
<?php endforeach; ?>

<form method="post" class="form-card">
    <?= csrf_field() ?>
    <div class="form-row">
        <label>ФИО *
            <input type="text" name="full_name" required value="<?= e($target['full_name']) ?>">
        </label>
        <label>Логин
            <input type="text" value="<?= e($target['username']) ?>" disabled>
        </label>
    </div>
    <div class="form-row">
        <label>Телефон
            <input type="text" name="phone" value="<?= e($target['phone'] ?? '') ?>">
        </label>
        <label>Роль
            <select name="role" <?= (int) $target['id'] === (int) $admin['id'] ? 'disabled' : '' ?>>
                <option value="mechanic" <?= $target['role'] === 'mechanic' ? 'selected' : '' ?>>Линейный механик</option>
                <option value="admin" <?= $target['role'] === 'admin' ? 'selected' : '' ?>>Главный механик</option>
                <option value="manager" <?= $target['role'] === 'manager' ? 'selected' : '' ?>>Менеджер (только просмотр техники)</option>
            </select>
            <?php if ((int) $target['id'] === (int) $admin['id']): ?>
                <input type="hidden" name="role" value="admin">
            <?php endif; ?>
        </label>
    </div>
    <label>Новый пароль <span class="hint">(оставьте пустым, если менять не нужно)</span>
        <input type="text" name="new_password" minlength="6" placeholder="не короче 6 символов">
    </label>
    <button type="submit" class="btn btn-primary">Сохранить</button>
</form>

<?php require __DIR__ . '/includes/footer.php'; ?>
