// Небольшие улучшения интерфейса

// Закрывать мобильное меню при клике на пункт навигации
document.addEventListener('DOMContentLoaded', function () {
    var nav = document.getElementById('mainNav');
    if (nav) {
        nav.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                nav.classList.remove('open');
            });
        });
    }
});
